    <?php
    phpinfo();
    ?>