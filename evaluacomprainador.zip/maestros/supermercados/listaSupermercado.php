<?php

include("../../inc/connection.php");

?>


<table class="table table-striped table-hover table-bordered table-sm table-responsive">
    <thead class="table-dark sticky-top">
        <tr>
            <th width="50">N°</th>
            <th width="200">Codigo</th>
            <th>Descripción</th>
            <th width="100">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $query = "SELECT * FROM supermercados WHERE estado = 1 ORDER BY id DESC";
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
                        $numero = 1;
            while ($row = $result->fetch_assoc()) {?>
                <tr>
                                        <td><?php echo $numero++; ?></td>
                    <td><?php echo $row['codigo']; ?></td>
                    <td><?php echo $row['descripcion']; ?></td>
                    <td>
                        <!-- <a href="editarSupermercado.php?id=<?php //echo $row['id']; ?>" class="btn btn-success btn-sm"><span class="material-icons align-bottom">edit</span></a> -->
                        <a href="eliminarsupermercado.php?id=<?php echo $row['id']; ?>" class="btn text-danger" title="Presione para eliminar" onclick="return confirm('¿Estás seguro de que deseas eliminar este supermercado?');"><span class="material-symbols-outlined align-bottom">delete</span>
                        </a>
                    </td>
                </tr>
            <?php }
        } else { ?>
            <tr>
                <td colspan="4">No se encontraron supermercados.</td>
            </tr>
        <?php }
        $conn->close();
        ?>
    </tbody>
</table>