<?php

function session_variable($carpeta,$now){

//habilita el uso de variables de sesion    
session_start();

//verifica si la sesion se encuentra creada
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {

} else {
    //redirige a la página de login si el usuario quiere ingresar sin iniciar sesion
    header('Location:'.$carpeta.'login/login.php');
exit;
}

//setea variable de sesion con hora actual
$now_val = $now;

// echo $now_val."<br>";
// echo $_SESSION['expire'];

//valida si la sesion se encuentra activa, si no, entrega alerta y luego redirige a pantalla de login
    if($now_val > $_SESSION['expire']) {
    session_destroy();
    echo '<script type="text/javascript">';
    echo 'alert("Sesion Finalizada. Se direccionará automaticamente a la pagina de login.");
          window.location = "'.$carpeta.'login/login.php";';
    echo '</script>';
    exit;
    }
}